package com.finra.springboot.utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class Email{
	@Autowired
    private JavaMailSender javaMailSender;
	
	 @Value("${emailSubject}")
	 private String emailSubject;
	 
	 @Value("${to}")
	 private String emailTo;
	 
	 @Value("${emailBody}")
	 private String emailBody;
	
	public void sendEmail() {

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(emailTo);
        msg.setSubject(emailSubject);
        msg.setText(emailBody);

        javaMailSender.send(msg);
	}

}