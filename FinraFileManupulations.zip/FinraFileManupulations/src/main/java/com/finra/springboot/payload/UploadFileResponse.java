package com.finra.springboot.payload;

import java.util.Comparator;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UploadFileResponse implements Comparable<UploadFileResponse> {
	
	@Id
	private Long id;
	private String fileName;
	private String fileDownloadUri;
	private String fileType;
	private long size;
	private Date date;
	
	public UploadFileResponse() {
		
	}

	public UploadFileResponse(Long id, String fileName, String fileDownloadUri, String fileType, long size, Date date) {
		super();
		this.id = id;
		this.fileName = fileName;
		this.fileDownloadUri = fileDownloadUri;
		this.fileType = fileType;
		this.size = size;
		this.date = date;
	}

	public String getFileName() {
		return fileName;
	}

	public String getFileDownloadUri() {
		return fileDownloadUri;
	}

	public String getFileType() {
		return fileType;
	}

	public long getSize() {
		return size;
	}
	
	public Date getDate() {
		return date;
	}
	
	@Override
	public int compareTo(UploadFileResponse uploadFileResponse) {
		return getDate().compareTo(uploadFileResponse.getDate());
	}

	

}
